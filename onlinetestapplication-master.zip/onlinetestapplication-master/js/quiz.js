let quiz=[
    {
        question:"which HTML element do we put the JavaScript?",
        option:[
            "1.<javasccript>",
            "2.<>js>",
            "3.<scripting>",
            "4.<script>",
        ],
        answer:4,
    },
    {
        question:"syntax referring external script xxx.js?",
        option:[
            "1. <script href=xxx.js>",
            "2. <script name=xxx.js>",
            "3. <script src=xxx.js>",
            "4. <script id=xxx.js>",
            
        ],
        answer:1,
    },
    {
        question:"Which type of JavaScript language is?",
        option:[
            "1.Object-Oriented",
            "2.Object-Based",
            "3.Assembly-language",
           "4.High-level",   
        ],
        answer:2,
    },
    {
        question:"How to create a checkbox in HTML?",
        option:[
            '1.<input type = "checkbox">',
            '2.<input type = "button">',
            '3.<checkbox>',
            '4.<input type = "check">',   
        ],
        answer:1,

    },
    {
        question:"The function and var are known as",
        option:[
            "1.Keywords",
            "2.Data types",
            "3.Declaration statements",
            "4.Prototypes",   
        ],
        answer:3,
    }
]